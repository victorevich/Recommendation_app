# MoodMatch

Система рекомендации серий сериалов на основе анализа эмоционального состояния пользователя.

## Стек

- **Backend**: FastAPI + ChromaDB + Sentence-Transformers (rubert)
- **Frontend**: HTML / CSS / Vanilla JS
- **Модель**: `DeepPavlov/rubert-base-cased-sentence`

## Запуск

### 1. Установка зависимостей

```bash
pip install -r requirements.txt
```

### 2. Запуск сервера

```bash
uvicorn main:app --reload
```

Открой http://localhost:8000

### 3. Инициализация базы данных (один раз)

Загрузи датасет через API:

```bash
curl -X POST http://localhost:8000/api/init-db \
  -F "file=@data/dataset-mood.csv"
```

Или через браузер — открой http://localhost:8000/docs и воспользуйся интерфейсом Swagger (`POST /api/init-db`).

После загрузки ChromaDB сохраняется в `data/chromadb/` — повторная инициализация не нужна.

## Структура проекта

```
moodmatch/
├── main.py                        # точка входа FastAPI
├── requirements.txt
├── data/
│   ├── dataset-mood.csv           # датасет
│   └── chromadb/                  # векторная база (создаётся автоматически)
├── backend/
│   ├── routers/
│   │   ├── search.py              # POST /api/search
│   │   ├── feedback.py            # POST /api/feedback
│   │   └── init_db.py             # POST /api/init-db
│   ├── services/
│   │   ├── embedder.py            # загрузка и инференс rubert
│   │   └── vector_store.py        # ChromaDB: add / search
│   └── models/
│       └── schemas.py             # Pydantic-схемы
└── frontend/
    ├── templates/
    │   └── index.html
    └── static/
        ├── css/style.css
        └── js/app.js
```

## API

| Метод | Путь | Описание |
|-------|------|----------|
| `GET` | `/` | Фронтенд |
| `POST` | `/api/search` | Семантический поиск серий |
| `POST` | `/api/feedback` | Лайк / дизлайк, обновление вектора пользователя |
| `POST` | `/api/init-db` | Загрузка CSV в ChromaDB |
| `GET` | `/api/db-status` | Количество серий в базе |
| `GET` | `/docs` | Swagger UI |
