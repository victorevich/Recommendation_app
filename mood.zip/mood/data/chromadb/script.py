import chromadb

client = chromadb.PersistentClient(path=".")
collection = client.get_collection('episodes_collection')

# Получаем все записи
all_data = collection.get()

# Выводим последние 5 записей
if len(all_data['ids']) > 0:
    last_n = 5
    print(f"📺 Последние {last_n} записей:")

    for i in range(max(0, len(all_data['ids']) - last_n), len(all_data['ids'])):
        idx = i  # индекс в списке
        print(f"\n[{i + 1}] ID: {all_data['ids'][idx]}")
        print(f"    Документ: {all_data['documents'][idx][:100]}...")
        if all_data['metadatas'][idx]:
            print(f"    Метаданные: {all_data['metadatas'][idx]}")
else:
    print("Коллекция пуста")